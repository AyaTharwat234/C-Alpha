First steps to connect to C-Alpha
1-open the the solution file with visual studio.
2- install Entity Framework  core (5.0.0) , Entity Framework sql server(5.0.0), Entity Framework tools (5.0.0) .
3-change connection string in appstetting.json file
4- from package console manager , make ( add-migreation command) then (update-database).
5- run the application .
